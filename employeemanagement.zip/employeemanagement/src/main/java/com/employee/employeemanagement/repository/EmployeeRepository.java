package com.employee.employeemanagement.repository;

import com.employee.employeemanagement.service.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
}