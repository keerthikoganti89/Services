package com.employee.employeemanagement.controller;

public class EmployeeView {
    private int empId;
    private String name;
    private int experience;
    private String joinDate;
    private boolean isApproved;
    private String location;
    private String status;
    private String designation;

    public EmployeeView(int empId, String name, int experience, String joinDate, boolean isApproved,
                        String location, String status, String designation) {
        this.setEmpId(empId);
        this.setName(name);
        this.setExperience(experience);
        this.setJoinDate(joinDate);
        this.setApproved(isApproved);
        this.setLocation(location);
        this.setStatus(status);
        this.setDesignation(designation);
    }

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public String getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(String joinDate) {
		this.joinDate = joinDate;
	}

	public boolean isApproved() {
		return isApproved;
	}

	public void setApproved(boolean isApproved) {
		this.isApproved = isApproved;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

    // Getters and setters (optional)
}
