package com.employee.employeemanagement.service;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional
public class DesignationService {

    @PersistenceContext
    private EntityManager entityManager;

    public List<Designation> getAllDesignations() {
        return entityManager
                .createQuery("SELECT d FROM Designation d", Designation.class)
                .getResultList();
    }
}
