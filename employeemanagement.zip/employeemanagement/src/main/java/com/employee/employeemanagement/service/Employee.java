package com.employee.employeemanagement.service;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "employee")
public class Employee {

    @Id
    @Column(name = "EMP_ID")
    private Integer empId;

    @Column(name = "NAME")
    private String name;

    @Column(name = "EXPERIENCE")
    private Integer experience;

    @Column(name = "JOIN_DATE")
    private LocalDate joinDate;

    @Column(name = "IS_APPROVED")
    private Boolean isApproved;

    @Column(name = "LOC_ID")
    private Integer locationId;

    @Column(name = "STA_ID")
    private Integer statusId;

    @Column(name = "DES_ID")
    private Integer designationId;

    // Constructors, getters, setters...


    public Employee() {}

    public Employee(int empId, String name, int experience, LocalDate joinDate, boolean isApproved,
                    int locationId, int stateId, int designationId) {
        this.empId = empId;
        this.name = name;
        this.experience = experience;
        this.joinDate = joinDate;
        this.isApproved = isApproved;
        this.locationId = locationId;
        this.statusId = stateId;
        this.designationId = designationId;
    }

    // Getters and setters...

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public LocalDate getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(LocalDate joinDate) {
        this.joinDate = joinDate;
    }

    public boolean isApproved() {
        return isApproved;
    }

    public void setApproved(boolean approved) {
        isApproved = approved;
    }

    public int getLocationId() {
        return locationId;
    }

    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    public int getStateId() {
        return getStateId();
    }

    public void setStateId(int stateId) {
        this.statusId = stateId;
    }

    public int getDesignationId() {
        return designationId;
    }

    public void setDesignationId(int designationId) {
        this.designationId = designationId;
    }
}
